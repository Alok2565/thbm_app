import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate, Link } from 'react-router-dom';
import { Container, Col, Form, Row, Button, InputGroup } from 'react-bootstrap';
import { Helmet } from 'react-helmet';
import authLogo from '../../assets/images/auth_icmr_logo.png';
import { useProject } from '../ProjectContext';

function UserLogin() {
    const { title } = useProject();
    const location = useLocation();
    const navigate = useNavigate();

    const [role, setRole] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [validated, setValidated] = useState(false);

    useEffect(() => {
        const queryParams = new URLSearchParams(location.search);
        const roleParam = queryParams.get('role');

        if (['icmr', 'committee'].includes(roleParam)) {
            setRole(roleParam);
        } else {
            navigate('/'); // Redirect if invalid or missing role
        }
    }, [location.search, navigate]);

    const handleSubmit = (event) => {
        event.preventDefault();
        const form = event.currentTarget;

        if (form.checkValidity() === false) {
            event.stopPropagation();
        } else {
            handleLogin();
        }

        setValidated(true);
    };

    const handleLogin = () => {
        if (role === 'icmr') {
            console.log('ICMR Login:', { email, password });
            // TODO: Add actual ICMR login logic here
        } else if (role === 'committee') {
            console.log('Committee Login:', { email, password });
            // TODO: Add actual Committee login logic here
        }
    };
    // 🔻 Role-based heading
    const roleHeading = {
        icmr: 'Login for ICMR Officers',
        committee: 'Login for Committee Members',
    };
    return (
        <>
            <Container className="py-3">
                <Helmet>
                    <meta charSet="utf-8" />
                    <title>{`Login | ${title}`}</title>
                </Helmet>
                <Col className="codex-authbox login mt-4 mb-4 mx-auto" md={6}>
                    <Col className="auth-header p-2">
                        <Col className="d-flex justify-content-center align-items-center mb-3">
                            <Link to="#">
                                <img
                                    className="img-fluid light-logo"
                                    src={authLogo}
                                    alt="logo"
                                    style={{ maxWidth: '400px' }}
                                />
                            </Link>
                        </Col>
                        <h5 className="text-center mb-3"><strong>{roleHeading[role]}</strong></h5>
                    </Col>
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="validationCustomEmail">
                                <Form.Label>Email</Form.Label>
                                <InputGroup hasValidation>
                                    <Form.Control
                                        type="email"
                                        name="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        required
                                    />
                                </InputGroup>
                            </Form.Group>
                        </Row>

                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="formGroupPassword">
                                <Form.Label className="d-flex justify-content-between">
                                    Password
                                    <Link
                                        to="/reset-password"
                                        className="text-end"
                                        style={{ fontSize: '14px', textDecoration: 'none' }}
                                    >
                                        Reset Password
                                    </Link>
                                </Form.Label>
                                <Form.Control
                                    type="password"
                                    name="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </Form.Group>
                        </Row>
                        <Col>
                            <Button type="submit" variant="primary" className="w-100">
                                Login
                            </Button>
                        </Col>
                        <h6><Link
                            to="/reset-password"
                            className="text-start"
                            style={{ fontSize: '14px', textDecoration: 'none' }}
                        >
                            Reset Password
                        </Link></h6>
                    </Form>
                </Col>
            </Container >
        </>
    );
}

export default UserLogin;
