import React from 'react'

function ImpExpRegister() {
    return (
        <div>
            <h2>Importer Exporter Registration</h2>
        </div>
    )
}

export default ImpExpRegister
