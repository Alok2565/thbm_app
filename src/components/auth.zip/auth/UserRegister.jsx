import React from 'react'

function UserRegister() {
    return (
        <div>
            <he>User Register</he>
        </div>
    )
}

export default UserRegister
