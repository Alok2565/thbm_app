import React, { useState } from 'react'
import { Link } from 'react-router-dom';
import { Container, Col, Form, Row, Button, InputGroup } from 'react-bootstrap';
import { Helmet } from 'react-helmet';
import authLogo from '../../assets/images/auth_icmr_logo.png';
import { useProject } from '../ProjectContext';
function ForgotPassword() {
    const { title } = useProject();
    const [email, setEmail] = useState('');
    const [validated, setValidated] = useState(false);

    const handleSubmit = (event) => {
        event.preventDefault();
        const form = event.currentTarget;

        if (form.checkValidity() === false) {
            event.stopPropagation();
        }

        setValidated(true);
    };
    return (
        <>
            <Container className="py-3">
                <Helmet>
                    <meta charSet="utf-8" />
                    <title>{`Forgot Password | ${title}`}</title>
                </Helmet>

                <Col className="codex-authbox login mt-4 mb-4 mx-auto" md={6}>
                    <Col className="auth-header p-2">
                        <Col className="d-flex justify-content-center align-items-center mb-3">
                            <Link to="#">
                                <img
                                    className="img-fluid light-logo"
                                    src={authLogo}
                                    alt="logo"
                                    style={{ maxWidth: '400px' }}
                                />
                            </Link>
                        </Col>
                        <h5 className="text-center mb-3"><strong>Forgot Your Password</strong></h5>
                        <p class="text-dark mb-4">Enter your email address and we'll send you an email with instructions to forgot your password.</p>
                    </Col>
                    <Form noValidate validated={validated} onSubmit={handleSubmit}>
                        <Row className="mb-3">
                            <Form.Group as={Col} controlId="validationCustomEmail">
                                <Form.Label>Email Address</Form.Label>
                                <InputGroup hasValidation>
                                    <Form.Control
                                        type="email"
                                        name="email"
                                        value={email}
                                        onChange={(e) => setEmail(e.target.value)}
                                        required
                                    />
                                    <Form.Control.Feedback type="invalid">
                                        Please provide a valid email.
                                    </Form.Control.Feedback>
                                </InputGroup>
                            </Form.Group>
                        </Row>
                        <Row className="mb-3">
                            <Col>
                                <Button type="submit" variant="primary" className="w-100">
                                    Send Forgot Link
                                </Button>
                            </Col>
                        </Row>
                    </Form>
                </Col>
            </Container>
        </>
    )
}

export default ForgotPassword
